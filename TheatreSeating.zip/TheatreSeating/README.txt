## Problem 3: Theatre Seating implemented in Java using Eclipse IDE
Source code : \src
Documentation : \doc
Test cases : \src\test << Since we do not use external dependency test cases implemented in core java Else we can implement the test cases using JUNIT.
Executable Jar : TheatreSeating.jar

Execution steps:
jar execution : 
1. Move to the jar path and type "java -jar TheatreSeating.jar"

Sample input:
6 6
3 5 5 3
4 6 6 4
2 8 8 2
6 6

Smith 2
Jones 5
Davis 6
Wilson 100
Johnson 3
Williams 4
Brown 8
Miller 12
done

Distribution of Seats Result:
Smith Row 1 Section 1
Jones Row 2 Section 2
Davis Row 1 Section 2
Wilson Sorry, we can't handle your party.
Johnson Row 2 Section 1
Williams Row 1 Section 1
Brown Row 4  Section 2
Miller Call to split party.
