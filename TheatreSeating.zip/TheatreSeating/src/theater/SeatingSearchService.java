package theater;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

/**
 * This is Seating Search Service Class.
 * @author Chandrashekhar
 *
 */
public class SeatingSearchService {

    /**
     * This method is use to parse the ticket request string into Request Object data.
     * @param ticketRequests
     * @return List<Request>
     * @throws NumberFormatException
     */
    public List<Request> parseTicketRequests(String ticketRequests) throws NumberFormatException{
        List<Request> requestsList = new ArrayList<Request>();
        Request request;
        String[] requests = ticketRequests.split(System.lineSeparator());
        for(String req : requests){
            String[] rData = req.split(" ");
            request = new Request();
            request.setName(rData[0]);
            try{
                request.setNoOfTickets(Integer.valueOf(rData[1]));
            }catch(NumberFormatException nfe){
                throw new NumberFormatException("'" + rData[1] + "'" + " is not valid request data. provide proper data.");
            }
            request.setFine(false);
            requestsList.add(request);
        }
        return requestsList;
    }
    
    /**
     * This method use to set convert layout string to layout object data .
     * @param rawLayoutData
     * @return Layout
     * @throws NumberFormatException
     */
    public Layout parseTheaterLayout(String rawLayoutData) throws NumberFormatException{
        int totalCapacityValue = 0, value;
        Layout theaterLayout = new Layout();
        Section section;
        List<Section> sectionsList = new ArrayList<Section>();
        String[] rows = rawLayoutData.split(System.lineSeparator());
        String[] sections;
        
        for(int i=0 ; i<rows.length ; i++){
            sections = rows[i].split(" ");
            for(int j=0 ; j<sections.length ; j++){
                try{
                
                    value = Integer.valueOf(sections[j]);
                }catch(NumberFormatException nfe){
                    throw new NumberFormatException("'" + sections[j] + "'" + " is not valid  capacity data . provide proper data.");
                }
                totalCapacityValue = totalCapacityValue + value;
                section = new Section();
                section.setRowNumber(i + 1);
                section.setSectionNumber(j + 1);
                section.setCapacity(value);
                section.setAvailableSeats(value);
                sectionsList.add(section);
            }
        }
        theaterLayout.setTotalCapacity(totalCapacityValue);
        theaterLayout.setAvailableSeats(totalCapacityValue);
        theaterLayout.setSections(sectionsList);
        return theaterLayout;
        
    }
    
   
    /**
     * This method actual process the ticket data based on provided layout and ticket requests.
     * @param layout
     * @param requests
     * @return List<Request>
     */
    public List<Request> processTicketRequests(Layout layout, List<Request> requests) {
        for(int i=0 ; i<requests.size() ; i++){
            Request request = requests.get(i);
            if(request.isFine())   continue;
             //-2 ==> indicator mean can not able to handle party
            if(request.getNoOfTickets() > layout.getAvailableSeats()){
                request.setRowNumber(-2);
                request.setSectionNumber(-2);
                continue;
            }
            List<Section> sections = layout.getSections();
        	for (Section section : sections) {
                if(request.getNoOfTickets() == section.getAvailableSeats()){
                    request.setRowNumber(section.getRowNumber());
                    request.setSectionNumber(section.getSectionNumber());
                    section.setAvailableSeats(section.getAvailableSeats() - request.getNoOfTickets());
                    layout.setAvailableSeats(layout.getAvailableSeats() - request.getNoOfTickets());
                    request.setFine(true);
                    break;
                }else if(request.getNoOfTickets() < section.getAvailableSeats()){
                    int requestNo = findComplementRequest(requests, section.getAvailableSeats() - request.getNoOfTickets(), i);
                    if(requestNo != -1){
                        request.setRowNumber(section.getRowNumber());
                        request.setSectionNumber(section.getSectionNumber());
                        section.setAvailableSeats(section.getAvailableSeats() - request.getNoOfTickets());
                        layout.setAvailableSeats(layout.getAvailableSeats() - request.getNoOfTickets());
                        request.setFine(true);
                        
                        Request complementRequest = requests.get(requestNo);
                        
                        complementRequest.setRowNumber(section.getRowNumber());
                        complementRequest.setSectionNumber(section.getSectionNumber());
                        section.setAvailableSeats(section.getAvailableSeats() - complementRequest.getNoOfTickets());
                        layout.setAvailableSeats(layout.getAvailableSeats() - complementRequest.getNoOfTickets());
                        complementRequest.setFine(true);
                        break;
                        
                    }else{
                        int sectionNo = findSectionByAvailableSeats(sections, request.getNoOfTickets());
                        if(sectionNo >= 0){
                            Section perferctSection = sections.get(sectionNo);
                            request.setRowNumber(perferctSection.getRowNumber());
                            request.setSectionNumber(perferctSection.getSectionNumber());
                            perferctSection.setAvailableSeats(perferctSection.getAvailableSeats() - request.getNoOfTickets());
                            layout.setAvailableSeats(layout.getAvailableSeats() - request.getNoOfTickets());
                            request.setFine(true);
                            break;
                        }else{
                            request.setRowNumber(section.getRowNumber());
                            request.setSectionNumber(section.getSectionNumber());
                            section.setAvailableSeats(section.getAvailableSeats() - request.getNoOfTickets());
                            layout.setAvailableSeats(layout.getAvailableSeats() - request.getNoOfTickets());
                            request.setFine(true);
                            break;
                        }
                    }
                }
            }
            
            //-1 ==> indicator mean split party required
            if(!request.isFine()){
                request.setRowNumber(-1);
                request.setSectionNumber(-1);
            }
        }
        return requests;
    }
    
    /**
     * This method is used to find the request based on provided current request index and other provided data.
     * @param requests
     * @param complementSeats
     * @param currentRequestIndex
     * @return int
     */
    private int findComplementRequest(List<Request> requests, int complementSeats, int currentRequestIndex){
        int requestNo = -1;
        for(int i=currentRequestIndex+1 ; i<requests.size() ; i++){
            Request request = requests.get(i);
            if(!request.isFine() && request.getNoOfTickets() == complementSeats){
                requestNo = i;
                break;
            }
        }
        return requestNo;
    }
    
    /**
     * This method find the section based on availability.
     * @param sections
     * @param availableSeats
     * @return int
     */
    private int findSectionByAvailableSeats(List<Section> sections, int availableSeats){
        int i=0;
        Section section = new Section();
        section.setAvailableSeats(availableSeats);
        Collections.sort(sections);
        int sectionNumber = Collections.binarySearch(sections, section, (o1,o2)->{ return o1.getAvailableSeats() - o2.getAvailableSeats();});
        
        //sectionNumber = 0 -- got section
        //sectionNumber > 0 -- chances of duplicate
        //sectionNumber < 0 -- no section
        if(sectionNumber > 0){
            for(i=sectionNumber-1 ; i>=0 ; i--){
                Section s = sections.get(i);
                if(s.getAvailableSeats() != availableSeats) break;
            }
            sectionNumber = i + 1;
        }
        return sectionNumber;
    }
    
    

}

