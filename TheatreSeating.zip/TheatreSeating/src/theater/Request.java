package theater;

/**
 * This is Request class
 * @author Chandrashekhar
 *
 */
public class Request {

    
    private int rowNumber;
    private int sectionNumber;
    private String name;
    private int noOfTickets;
    private boolean isFine;
    
	public int getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}

	public int getSectionNumber() {
		return sectionNumber;
	}


	public void setSectionNumber(int sectionNumber) {
		this.sectionNumber = sectionNumber;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNoOfTickets() {
		return noOfTickets;
	}


	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}


	public boolean isFine() {
		return isFine;
	}


	public void setFine(boolean isFine) {
		this.isFine = isFine;
	}

}
