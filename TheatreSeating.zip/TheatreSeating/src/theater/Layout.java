package theater;

import java.util.List;

/**
 * This is Layout class.
 * @author Chandrashekhar
 *
 */
public class Layout {

    private int totalCapacity;
    private int availableSeats;
    private List<Section> sections;
	public int getTotalCapacity() {
		return totalCapacity;
	}
	public void setTotalCapacity(int totalCapacity) {
		this.totalCapacity = totalCapacity;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	public List<Section> getSections() {
		return sections;
	}
	public void setSections(List<Section> sections) {
		this.sections = sections;
	}
}

