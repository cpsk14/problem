package theater;

import java.util.List;
import java.util.Scanner;

/**
 * This is main Seat class contains main method.
 * @author Chandrashekhar
 *
 */
public class Seat {
	
	StringBuilder ticketRequests = new StringBuilder();
	StringBuilder layout = new StringBuilder();
	
    /**
     * This is main startup method.
     * @param args
     */
    public static void main(String[] args) {    
    	Seat theaterSeat=new Seat();
    	try {
    		theaterSeat.readData();
    		List<Request> requests = theaterSeat.processData();
    		if(requests !=null)
    			theaterSeat.printResult(requests);
    		else
    			System.out.println("No distribution of Seats Result:");
    		
    	}catch (Exception e) {
			System.out.println("Unable to process request due to : "+e.getMessage());
			e.printStackTrace();
		}
    }
    
    /**
     * This method read the data from console and parse it.
     */
    private void readData() {
    	boolean isLayoutFinished = false;
        String lineText;        
        System.out.println("Please provide Theater Layout, Requests seperated by an blank line & to process and finish type 'done'\n");
        Scanner inputLine = new Scanner(System.in);
        while((lineText = inputLine.nextLine()) != null && !lineText.equalsIgnoreCase("done")){
            if(lineText.length() == 0){
                isLayoutFinished = true;
                continue;
            }
            if(!isLayoutFinished){
                layout.append(lineText + System.lineSeparator());
            }else{
                ticketRequests.append(lineText + System.lineSeparator());
            }
        }
        inputLine.close();
    }
    
    
    /**
     * This method is process the data.
     */
    public List<Request> processData() throws Exception {
    	SeatingSearchService seatingSearchService = new SeatingSearchService();
    	List<Request> requests=null;
        try{
            Layout theaterLayout = seatingSearchService.parseTheaterLayout(layout.toString());
            requests = seatingSearchService.parseTicketRequests(ticketRequests.toString());
            requests=seatingSearchService.processTicketRequests(theaterLayout, requests);
            
        }catch(NumberFormatException nfe){
            System.out.println(nfe.getMessage());
            throw new NumberFormatException(nfe.getMessage());
        }catch(Exception e){
        	e.printStackTrace();
        	throw new Exception(e.getMessage());
        }
    	return requests;
    }
    
    /**
     * This method is used to print the result.
     * @param requests
     */
    private void printResult(List<Request> requests) {
    	//Print the result
        System.out.println("Distribution of Seats Result:");
        requests.forEach((request)->System.out.println(getStatus(request)));
    }
    
    /**
     * This method is used to print the result.
     * @param request
     * @return String
     */
    public String getStatus(Request request){
        String status = null;
        if(request.isFine()){
            status = request.getName() + " " + "Row " + request.getRowNumber() + " " + "Section " + request.getSectionNumber();
        }else{
            if(request.getRowNumber() == -1 && request.getSectionNumber() == -1){
                status = request.getName() + " " + "Call to split party.";
            }else{
                status = request.getName() + " " + "Sorry, we can't handle your party.";
            }
        }
        return status;
    }
    
    public void setTicketRequests(StringBuilder ticketRequests) {
		this.ticketRequests = ticketRequests;
	}

	public void setLayout(StringBuilder layout) {
		this.layout = layout;
	}
    
}

