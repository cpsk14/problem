package test;

import java.util.List;

import theater.Request;
import theater.Seat;

/**
 * This class is used to test the Theatre Seating implementation.
 * @author Chandrashekhar
 *
 */
public class TestTheatreSeating {

	/**
	 * This is main method from testing
	 * @param args
	 */
	public static void main(String[] args) {
		TestTheatreSeating testTheatreSeating=new TestTheatreSeating();
		try {
			testTheatreSeating.testCase1();
			testTheatreSeating.testCase2();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * This is test case 1.
	 * @throws Exception 
	 */
	private void testCase1() throws Exception {
		StringBuilder ticketRequests = new StringBuilder();
		StringBuilder layout = new StringBuilder();
		layout.append("6 6");
		ticketRequests.append("Smith 2");
		String expectedResult="Smith Row 1 Section 1";
		if(callService(layout,ticketRequests,expectedResult))
			System.out.println("Test case 1 is PASS");
		else
			System.out.println("Test case 1 is failed");
	}
	
	/**
	 * This is test case 2.
	 * @throws Exception 
	 */
	private void testCase2() throws Exception {
		StringBuilder ticketRequests = new StringBuilder();
		StringBuilder layout = new StringBuilder();
		layout.append("6 6");
		ticketRequests.append("Miller 12");
		String expectedResult="Miller Call to split party.";
		if(callService(layout,ticketRequests,expectedResult))
			System.out.println("Test case 2 is PASS");
		else
			System.out.println("Test case 2 is failed");
	}
	
	/**
	 * This method used to give call to Theatre Service for testing.
	 * @param layout
	 * @param ticketrequest
	 * @param expectedResult
	 * @return boolean
	 * @throws Exception 
	 */
	private boolean  callService(StringBuilder layout, StringBuilder ticketrequest,String expectedResult) throws Exception {
		Seat seat=new Seat();
		seat.setLayout(layout);
		seat.setTicketRequests(ticketrequest);
		List<Request> requests = seat.processData();
		if(requests !=null && !requests.isEmpty())
			return seat.getStatus(requests.get(0)).equalsIgnoreCase(expectedResult);
		else
			return false;
	}

}
